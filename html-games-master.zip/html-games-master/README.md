# One HTML Games & Utils

Built during COVID-19 lockdown in my base.

### 📃 One Single HTML File

No CSS, Javascript Import. All Embedded in One HTML File.

### 🚚 Super Fast Code Shipping

Loading Single HTML File... and Done!

### 🛒 No Dependency

Full Vanilia Javascript

### 😈 No code split

I Gave up Maintenance...

### ⚠ Support Only PC Chrome Browser

No Mobile Support 🤔

## [Brick Breaker](https://html-games.surge.sh/brick-breaker)

<img alt="sbb" src="https://user-images.githubusercontent.com/22253556/81933996-2cf06900-9629-11ea-9b4e-31cee7502d29.png " width="400px"/>

## [Korean Chess](https://html-games.surge.sh/janggi)

<img alt="janggji" src="https://user-images.githubusercontent.com/22253556/81934129-645f1580-9629-11ea-89b9-5bdf53918eb2.png" width="400px"/>

## [Gomoku](https://html-games.surge.sh/omok)

<img alt="gomoku" src="https://user-images.githubusercontent.com/22253556/81934177-7ccf3000-9629-11ea-8478-fb1894a93e84.png" width="400px"/>

## [Tetris](https://html-games.surge.sh/tetris)

<img alt="tetris" src="https://user-images.githubusercontent.com/22253556/81934265-a5572a00-9629-11ea-9f8f-6d807f4f37cb.png" width="400px"/>

## [Kanban Board](https://html-games.surge.sh/kanban)

<img alt="canban1" src="https://user-images.githubusercontent.com/22253556/81934493-fff08600-9629-11ea-92e1-eadd3c0f3393.png" width="400px"/>

<img alt="canban2" src="https://user-images.githubusercontent.com/22253556/81934425-e51e1180-9629-11ea-85d4-bff5f6e671c8.png" width="400px"/>

## [Maze Generator](https://html-games.surge.sh/maze)

<img alt="maze" src="https://user-images.githubusercontent.com/22253556/82049751-dac74a80-96f1-11ea-96d8-f3fff2f002a9.png" width="400px"/>

## [Stack!](https://html-games.surge.sh/stack)

<img alt="stack" src="https://user-images.githubusercontent.com/22253556/86470747-07edbc00-bd77-11ea-9457-aee76662e62c.png" width="400px"/>
